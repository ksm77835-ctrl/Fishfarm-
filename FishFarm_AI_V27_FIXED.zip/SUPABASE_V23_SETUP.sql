-- FishFarm AI V25 database notes (no new SQL required)
-- Run once in Supabase SQL Editor. Existing data is preserved.

ALTER TABLE public.harvest_records
ADD COLUMN IF NOT EXISTS fish_count INTEGER DEFAULT 0;

CREATE TABLE IF NOT EXISTS public.growth_records (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  pond_id UUID NOT NULL REFERENCES public.ponds(id) ON DELETE CASCADE,
  avg_weight_g NUMERIC(12,2) NOT NULL,
  fish_count INTEGER NOT NULL,
  biomass_kg NUMERIC(14,2) NOT NULL,
  measurement_date DATE NOT NULL DEFAULT CURRENT_DATE,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.growth_records ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='growth_records' AND policyname='fishfarm_growth_select') THEN
    CREATE POLICY fishfarm_growth_select ON public.growth_records FOR SELECT TO anon USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='growth_records' AND policyname='fishfarm_growth_insert') THEN
    CREATE POLICY fishfarm_growth_insert ON public.growth_records FOR INSERT TO anon WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='growth_records' AND policyname='fishfarm_growth_delete') THEN
    CREATE POLICY fishfarm_growth_delete ON public.growth_records FOR DELETE TO anon USING (true);
  END IF;
END $$;
