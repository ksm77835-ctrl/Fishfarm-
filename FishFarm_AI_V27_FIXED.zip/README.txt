FishFarm AI V27 FIXED

Fixes in V27:
- Harvest saves fish_species and harvest_date to Supabase.
- Cloud sync reads fish_species and harvest_date from Supabase.
- Harvest form clearly labels the entry value as Current Harvest Revenue.
- Harvest screen shows Farm Total Harvest Revenue from all loaded harvest records.
- Legacy harvest rows with fish_count = 0 are flagged instead of silently treating the count as valid.

No new SQL is required if the existing harvest_records table already contains fish_species, harvest_date, fish_count, quantity_kg, price_per_kg and revenue.
